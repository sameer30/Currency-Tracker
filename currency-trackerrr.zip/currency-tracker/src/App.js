import React, { useEffect, useState } from "react";
import axios from "axios";
import { format, subDays, isBefore } from "date-fns";
import './index.css';

const API_BASE = "https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api";
const DEFAULT_BASE = "gbp";
const DEFAULT_CURRENCIES = ["usd", "eur", "jpy", "chf", "cad", "aud", "zar"];
const MIN_CURRENCIES = 3;
const MAX_CURRENCIES = 7;

export default function App() {
  const [baseCurrency, setBaseCurrency] = useState(DEFAULT_BASE);
  const [availableCurrencies, setAvailableCurrencies] = useState({});
  const [selectedCurrencies, setSelectedCurrencies] = useState(DEFAULT_CURRENCIES);
  const [date, setDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [exchangeData, setExchangeData] = useState({});
  const [error, setError] = useState(null);

  useEffect(() => {
    axios
      .get(`${API_BASE}@latest/v1/currencies.json`)
      .then((res) => setAvailableCurrencies(res.data))
      .catch((err) => console.error("Currency list fetch failed:", err));
  }, []);

  useEffect(() => {
    const fetchExchangeRates = async () => {
      const results = {};
      const promises = [];

      for (let i = 0; i < 7; i++) {
        const d = format(subDays(new Date(date), i), "yyyy-MM-dd");
        const url = `${API_BASE}@${d}/v1/currencies/${baseCurrency}.json`;

        promises.push(
          axios
            .get(url)
            .then((res) => {
              results[d] = res.data[baseCurrency];
            })
            .catch(() => {
              results[d] = null;
            })
        );
      }

      await Promise.all(promises);
      setExchangeData(results);
    };

    fetchExchangeRates();
  }, [baseCurrency, date]);

  const handleDateChange = (e) => {
    const newDate = new Date(e.target.value);
    const minDate = subDays(new Date(), 90);

    if (isBefore(newDate, minDate)) {
      alert("Date must be within the last 90 days.");
      return;
    }

    setDate(format(newDate, "yyyy-MM-dd"));
  };

  const handleAddCurrency = (code) => {
    if (
      selectedCurrencies.length >= MAX_CURRENCIES ||
      selectedCurrencies.includes(code)
    )
      return;
    setSelectedCurrencies([...selectedCurrencies, code]);
  };

  const handleRemoveCurrency = (code) => {
    if (selectedCurrencies.length <= MIN_CURRENCIES) return;
    setSelectedCurrencies(selectedCurrencies.filter((c) => c !== code));
  };

  return (
    <div className="container">
      <h1>Currency Exchange Tracker</h1>

      <div className="controls">
        <div>
          <label>Base Currency:</label><br />
          <select value={baseCurrency} onChange={(e) => setBaseCurrency(e.target.value)}>
            {Object.entries(availableCurrencies).map(([code, name]) => (
              <option key={code} value={code}>
                {code.toUpperCase()} - {name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label>Select Date:</label><br />
          <input
            type="date"
            max={format(new Date(), "yyyy-MM-dd")}
            value={date}
            onChange={handleDateChange}
          />
        </div>
      </div>

      <div className="tracked-currencies">
        <label>Tracked Currencies:</label><br />
        {selectedCurrencies.map((code) => (
          <span key={code} className="currency-tag">
            {code.toUpperCase()}
            <button onClick={() => handleRemoveCurrency(code)}>X</button>
          </span>
        ))}

        <div>
          <select class="currStyle" onChange={(e) => handleAddCurrency(e.target.value)}>
            <option value="">Add currency</option>
            {Object.keys(availableCurrencies)
              .filter((code) => !selectedCurrencies.includes(code))
              .map((code) => (
                <option key={code} value={code}>
                  {code.toUpperCase()} - {availableCurrencies[code]}
                </option>
              ))}
          </select>
        </div>
      </div>

      <div>
        <table>
          <thead>
            <tr>
              <th>Date</th>
              {selectedCurrencies.map((code) => (
                <th key={code}>{code.toUpperCase()}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {Object.keys(exchangeData)
              .sort()
              .reverse()
              .map((dateKey) => (
                <tr key={dateKey}>
                  <td>{dateKey}</td>
                  {selectedCurrencies.map((code) => (
                    <td key={code}>
                      {exchangeData[dateKey]?.[code]?.toFixed(4) ?? "N/A"}
                    </td>
                  ))}
                </tr>
              ))}
          </tbody>
        </table>
      </div>

      {error && <div style={{ color: "red" }}>{error}</div>}
    </div>
  );
}
